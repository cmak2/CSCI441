Calvin Mak/ cmak@mymail.mines.edu
Fall 2019 - Assignment 3 - Enter the Park
My program creates a cloud-like Vehicle. It moves forward and backwards with w and s respectively. It turns left with the a key and right with the d key.
The camera is adjustable with the mouse left click button. Holding control and dragging with the mouse zooms in and out. The cloud thing has a orangle backside/tail and a gold/yellow front. 
The clouds are intended to randomly appear and disappear.
The cloud turns dark when it stops, and white when it moves.
The vehicle can run into boundaries, but not cross.
To compile the code, it is easiest to run it in CLion with the cmake file.
I had issues with orientation of my vehicle. There might be a slight offset due to how it was drawn. There might be some gaps in the vehicle since its psuedo-RNG. 
This assignment took me 24 hours.
9, we used lab 3 as the base of the code, when slight modifications.
4, it was frustrating getting stuff to work right.
