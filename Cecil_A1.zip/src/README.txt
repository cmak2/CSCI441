Calvin Mak: Cecil
Assignment 1 - Hoist Your Sign
The program uses various transformations upon the letters of my hero's name.
The crest is essentially a tornado in a circle.

To run and compile the code, simply go into the appropriate directory in a shell or command line. 
First compile with the command "make" in the appropriate directory.
Then run the program ./lab00b which should be the appropriate exe.

The alternative is to simply run the program in CLion.

Bugs may be some graphical messiness, but nothing too serious.
This took me about 8 hours to complete.
8, the lab was very helpful, but didn't explain multiple transformations too well.
5, the transformations were difficult to properly perform.