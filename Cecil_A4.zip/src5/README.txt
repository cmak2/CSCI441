Calvin Mak/ cmak@mymail.mines.edu
Fall 2019 -  Assignment 4 - Sell Out
The program features a faery revolving around a bezier curve centered around the vehicle. The vehicle can move via w,a,s,d.
The camera moves through mouse controls: dragging to rotate, ctrl + drag to control distance.
To compile the code, it is easiest to run it in CLion with the cmake file.
I had issues with orientation of my vehicle. There might be a slight offset due to how it was drawn. There might be some gaps in the vehicle since its psuedo-RNG. 
This assignment took me 2 hours.
I had issues with my ctrl + mouse drag for the camera zoom, it is buggy and occasional. Sometimes it requires multiple tries.
9, we used assignment 3 as the base of the code with modifications to lab 4, when slight modifications.
8, it was a lot easier than previous assignments.
