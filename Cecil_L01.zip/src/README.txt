10 The lab was pretty fun.
I like the lab was able to walk us through how to do this.
It took about 1 hour.
No.
