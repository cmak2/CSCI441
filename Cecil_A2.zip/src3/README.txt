/*
 *  CSCI 441 Computer Graphics, Fall 2018
 *
 *  Project: a2
 *  File: main.cpp
 *
 *  Author: Calvin Mak
 *
 *  Description:
 *		Assignment 2: Hero and animations
 */

Questions:
1) a)
    glm::mat4 rotateMtx = glm::rotate(glm::mat4(1.0f), glm::vec3(cos(theta_r), cos(theta_r),0.0f));
    glMultMatrixf(&rotateMtx[0][0]);
    glm::mat4 transMtx = glm::translate(x,y,0);
    glMultMatrixf(&transMtx[0][0]);
    glMultMatrix(&(inverse(rotateMtx))[0][0]);
    drawHelmet();
    glMultMatrix(&(inverse(transMtx))[0][0]);
   b)
     glm::mat4 transMtx = glm::translate(i,j,0);
     glMultMatrixf(&transMtx[0][0]);
     glLoadIdentity();
     glm::mat4 rotateMtx = glm::rotate(glm::mat4(1.0f), glm::vec3(cos(theta_r), cos(theta_r),0.0f));
     glMultMatrixf(&rotateMtx[0][0]);
     drawHelmet();
     glMultMatrix(glm::mat4(1.0f));
    c)
     glMultMatrix(glm::mat4(1,0,0,0,cot(theta_s),1,0,0,0,0,1,0,0,0,0,1));

   Cecil/Calvin Mak
   Assignment 2: Employee of the Month
   This program has many various functions.
   The character will move around the screen based on interactive arrow keys. When the character hits boundaries, he will spawn on the other side.
   When the character is clicked 3 times, he will change color. Clicked once more, he changes back.
   The character's torso "naturally" increases and decreases to symbolize breathing.
   Clicking various parts of the screen spawns a little spike ball/explosion from the mouse that bounces around (a "feature").
   To run the program, simply open console, cd to the appropriate directory. And run make.
   Then you can run the program with ./a2_starter.

   I used CLion though, so you can just run it in CLion.
   I had many bugs and issues with the program, thus the program is currently a mess. I disabled unused features, but there are still lots of lingering, though disabled code.
   I had major difficulty using maps and other libraries in c++ which took a toll on my time coding. The little spikeball/explosion I had difficulty and centering it around the mouse location.
   As the scaling made it bounce out since it spawns from the corner of the mouse rather than centering.
   The assignment took me at least 3 days.
   7 The lab was sorta helpful.
   7 I wish I had more time making it better and cleaner.