/*
 *  CSCI 441 Computer Graphics, Fall 2017
 *
 *  Project: a2
 *  File: main.cpp
 *
 *  Author: Calvin Mak - Fall 2017
 *
 *  Description:
 *		Setting up Hero Actions and functions
 */

#include <GLFW/glfw3.h>		// include GLFW framework header

#ifdef __APPLE__			// if compiling on Mac OS
#include <OpenGL/gl.h>
#else						// else compiling on Linux OS
#include <GL/gl.h>
#endif

// include GLM libraries and matrix functions
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>

#include <stdio.h>				// for printf functionality
#include <stdlib.h>				// for exit functionality
#include <time.h>               // for time functionality
#include <vector>               // for vector functionality
#include <string>               // for std::string functionality
#include <utility>
#include <math.h>
#include <iostream>
using std::srand;
using std::string;
using std::cout;

// include everything necessary to make our world map work
// depends upon SOIL library
#include "WorldMap.h"

//*************************************************************************************
//
// Global Parameters

// global variables to keep track of window width and height.
// set to initial values for convenience, but we need variables
// for later on in case the window gets resized.
int WINDOW_WIDTH = 512, WINDOW_HEIGHT = 512;

float translateX = 0.0f;
float translateY = 0.0f;
bool heroHover = false;
bool inhale = true;                                 //Simulate breathing
//Avatar Boundaries Mapping will currently be rectangles (as is easiest)
//Each Limb/Body part will have a Rectangular/Boxed Mask that is used for scanning and maintaining locations of each body part in each of the 6 directions
//An Actual Map with tuples could also be used, but would be messy and inefficient

//HEAD
float HERO_HEAD_X = 0., HERO_HEAD_Y = 0., HERO_HEAD_Z = 0.;
float HERO_HEAD_NX = 0., HERO_HEAD_NY = 0., HERO_HEAD_NZ = 0.;
std::vector<float> headX = {216.0f,216.,296.,296.};
std::vector<float> headY = {316.,376.,316.,376.};

//NECK
float HERO_NECK_X = 0., HERO_NECK_Y = 0., HERO_NECK_Z = 0.;
float HERO_NECK_NX = 0., HERO_NECK_NY = 0., HERO_NECK_NZ = 0.;
vector<float> neckX = {236.,236.,276.,276.}, neckY = {296.,336.,296.,336.};

//BODY
float HERO_BODY_X = 0., HERO_BODY_Y = 0., HERO_BODY_Z = 0.;
float HERO_BODY_NX = 0., HERO_BODY_NY = 0., HERO_BODY_NZ = 0.;
vector<float> bodyX = {226.,226.,286.,286.}, bodyY = {216.,296.,216.,296.};
vector<float> upperTorsoX = {226.,226.,286.,286.}, upperTorsoY = {236.,296.,236.,296.};

//LEFT ARM
float HERO_LARM_X = 0., HERO_LARM_Y = 0., HERO_LARM_Z = 0.;
float HERO_LARM_NX = 0., HERO_LARM_NY = 0., HERO_LARM_NZ = 0.;
vector<float> lArmX= {211.,211.,226.,226.}, lArmY = {211.,296.,211.,296.};

//RIGHT ARM
float HERO_RARM_X = 0., HERO_RARM_Y = 0., HERO_RARM_Z = 0.;
float HERO_RARM_NX = 0., HERO_RARM_NY = 0., HERO_RARM_NZ = 0.;
vector<float> rArmX = {286.,286.,301.,301.}, rArmY = {211.,296.,211.,296.};

//LEFT LEG
float HERO_LLEG_X = 0., HERO_LLEG_Y = 0., HERO_LLEG_Z = 0.;
float HERO_LLEG_NX = 0., HERO_LLEG_NY = 0., HERO_LLEG_NZ = 0.;
vector<float> lLegX = {231.,231,246.,246.}, lLegY = {176.,216.,176.,216.};
//RIGHT LEG
float HERO_RLEG_X = 0., HERO_RLEG_Y = 0., HERO_RLEG_Z = 0.;
float HERO_RLEG_NX = 0., HERO_RLEG_NY = 0., HERO_RLEG_NZ = 0.;
vector<float> rLegX = {266.,266.,281.,281.}, rLegY = {176.,216.,176.,216.};

//Input values
int clickCount = 0;
float tickCounter = -1.0;
bool startBoom = false;
bool mouseClick = false;
bool mouseRClick = false;
//Toggles
bool dark = false;

//std::string weapon = "";
double mouseX = 0.0, mouseY = 0.0;

void toggle(bool &object) {
    if (object) { object = false;
    } else {object = true; }
}

bool selectHead(double x, double y) {
    if (x <= HERO_HEAD_X && x >= HERO_HEAD_NX && y <= HERO_HEAD_Y && y >= HERO_HEAD_NY) {
        return true;
    } return false;
}

bool selectNeck(double x, double y) {
    if (x <= HERO_NECK_X && x >= HERO_NECK_NX && y <= HERO_NECK_Y && y >= HERO_NECK_NY) {
        return true;
    } return false;
}

bool selectBody(double x, double y) {
    if (x <= HERO_BODY_X && x >= HERO_BODY_NX && y <= HERO_BODY_Y && y >= HERO_BODY_NY) {
        return true;
    } return false;
}

bool selectLArm(double x, double y) {
    if (x <= HERO_LARM_X && x >= HERO_LARM_NX && y <= HERO_LARM_Y && y >= HERO_LARM_NY) {
        return true;
    } return false;
}

bool selectRArm(double x, double y) {
    if (x <= HERO_RARM_X && x >= HERO_RARM_NX && y <= HERO_RARM_Y && y >= HERO_RARM_NY) {
        return true;
    } return false;
}

bool selectLLeg(double x, double y) {
    if (x <= HERO_LLEG_X && x >= HERO_LLEG_NX && y <= HERO_LLEG_Y && y >= HERO_LLEG_NY) {
        return true;
    } return false;
}

bool selectRLeg(double x, double y) {
    if (x <= HERO_RLEG_X && x >= HERO_RLEG_NX && y <= HERO_RLEG_Y && y >= HERO_RLEG_NY) {
        return true;
    } return false;
}

bool checkSelectHero(double x, double y) {
    if(!selectHead(x, y)) {
        if(!selectBody(x, y)) {
            if (!selectNeck(x,y)) {
                if (!selectLArm(x, y)) {
                    if (!selectRArm(x, y)) {
                        if (!selectLLeg(x, y)) {
                            if (!selectRLeg(x, y)) {
                                return false;
                            }
                        }
                    }
                }
            }
        }
    }
    return true;
}
//Determines minimum and maximum values for vectors
float min(vector<float> &dim) {
    if (dim.empty()) { return 0; }
    float minimum = dim.at(0);
    for(auto i : dim) {
        if( i < minimum) {minimum = i;}
    }
    return minimum;
}

float max(vector<float> &dim) {
    if (dim.empty()) { return 0; }
    float maximum = dim.at(0);
    for(auto i : dim) {
        if( i > maximum) {maximum = i;}
    }
    return maximum;
}
//*************************************************************************************
//
// Event Callbacks

static void error_callback(int error, const char* description) {
    fprintf(stderr, "[ERROR]: %s\n", description);
}

void keyboard_callback(GLFWwindow *win, int key, int scancode, int action, int mods ) {
    if (action == GLFW_PRESS || action == GLFW_REPEAT) {
        switch(key) {
            case GLFW_KEY_ESCAPE:
                glfwSetWindowShouldClose(win, GL_TRUE);
                break;
            case GLFW_KEY_LEFT:
                if (translateX - 1 < -256) {
                    translateX = 256;
                } else {
                    translateX--;
                }
                moveLeft();
                break;
            case GLFW_KEY_UP:
                if (translateY + 1 > 256) {
                    translateY = -256;
                } else {
                    translateY = translateY + 1;
                }
                moveUp();
                break;
            case GLFW_KEY_RIGHT:
                if (translateX + 1 > 256) {
                    translateX = -256;
                } else {
                    translateX++;
                }
                moveRight();
                break;
            case GLFW_KEY_DOWN:
                if (translateY - 1 < -256) {
                    translateY = 256;
                } else {
                    translateY--;
                }
                moveDown();
                break;
            case (GLFW_KEY_DOWN && GLFW_KEY_RIGHT):                       //Was just testing
                if (translateX + 1 > 256) {
                    translateX = -256;
                } else {
                    translateX++;
                }
                if (translateY - 1 < -256) {
                    translateY = 256;
                } else {
                    translateY--;
                }
                moveDown();
                moveRight();
                break;
        }
}
}

void mouse_button_callback( GLFWwindow *window, int button, int action, int mods ) {
    if(button == GLFW_MOUSE_BUTTON_LEFT) {
        if (action == GLFW_PRESS) {
            mouseClick = true;
            if(!startBoom) {
                if (!heroHover) {
                    tickCounter = 1.0f;
                    startBoom = true;
                    //cout << startBoom;
                }
            }
        }
        else if(action == GLFW_RELEASE) {
            mouseClick = false;
        }
        if(heroHover && mouseClick) {
            clickCount++;
            if (clickCount < 3) {
                clickCount++;
            } else {
                clickCount = 0;
                toggle(dark);
            }
        }
    }
}

void cursor_callback(GLFWwindow *window, double x, double y ) {
    mouseX = x;
    mouseY = WINDOW_HEIGHT - y;
    if(checkSelectHero(x,WINDOW_HEIGHT-y)) {
        heroHover = true;
    } else { heroHover = false; }
}
//*************************************************************************************
//
// Setup Functions

//
//  void setupGLFW()
//
//      Used to setup everything GLFW related.  This includes the OpenGL context
//	and our window.
//


void drawLeftLeg() {
    vector<float> x = lLegX;
    vector<float> y = lLegY;
    glBegin(GL_TRIANGLE_STRIP); {
        if (dark) {
            glColor4f(0.541f, 0.475f, 0.365f, 0.7f);
        } else {
            glColor4f(1.0f, 0.85f, 0.72f, 1.0f);
        }
        for(int i = 0; i < x.size(); i++) {
            glVertex2f(x[i],y[i]);
        }
    } glEnd();
    HERO_LLEG_NX = min(lLegX);
    HERO_LLEG_NY = min(lLegY);
    HERO_LLEG_Y = max(lLegY);
    HERO_LLEG_X = max(lLegX);
}

void drawRightLeg() {
    vector<float> x = rLegX;
    vector<float> y = rLegY;
    glBegin(GL_TRIANGLE_STRIP); {
        if (dark) {
            glColor4f(0.541f, 0.475f, 0.365f, 0.7f);
        } else {
            glColor4f(1.0f, 0.85f, 0.72f, 1.0f);
        }
        for(int i = 0; i < x.size(); i++) {
            glVertex2f(x[i],y[i]);
        }
    }glEnd();
    HERO_RLEG_NX = min(rLegX);
    HERO_RLEG_NY = min(rLegY);
    HERO_RLEG_Y = max(rLegY);
    HERO_RLEG_X = max(rLegX);
}



void drawBody() {
    vector<float> x = bodyX;
    vector<float> y = bodyY;
    glBegin(GL_TRIANGLE_STRIP); {
        glColor4f(0.8f,0.8f,0.8f,0.0f);
        for(int i = 0; i < x.size(); i++) {
            glVertex2f(x[i],y[i]);
        }
    }glEnd();
    glBegin(GL_LINE_STRIP); {
        glColor4f(0.f,0.f,0.0f,1.0f);
        glVertex2f(x[3]+1,y[3]+1);
        glVertex2f(x[2]+1,y[2]-1);
        glVertex2f(x[0]-1,y[0]-1);
        glVertex2f(x[1]-1,y[1]+1);
    }glEnd();


    HERO_BODY_NY = min(bodyY);
    HERO_BODY_Y = max(bodyY);
}

void drawUpperTorso() {
    vector<float> x = upperTorsoX;
    vector<float> y = upperTorsoY;
    if(inhale) {
        upperTorsoX[1] = upperTorsoX[1] - 0.01;
        upperTorsoX[3] = upperTorsoX[3] + 0.01;
        if (upperTorsoX[3] > 296) {inhale = false;}
    } else {
        upperTorsoX[1] = upperTorsoX[1] + 0.01;
        upperTorsoX[3] = upperTorsoX[3] - 0.01;
        if (upperTorsoX[3] < 286) {inhale = true; }
    }
    glBegin(GL_TRIANGLE_STRIP); {
        glColor4f(0.8f,0.8f,0.8f,0.0f);
        for(int i = 0; i < x.size(); i++) {
            glVertex2f(x[i],y[i]);
        }
    }glEnd();
    glBegin(GL_LINE_STRIP); {
        glColor4f(0.f,0.f,0.0f,1.0f);
        glVertex2f(x[0],y[0]);
        glVertex2f(x[1],y[1]);
        glVertex2f(x[3],y[3]);
        glVertex2f(x[2],y[2]);
    }glEnd();
    HERO_BODY_NX = min(upperTorsoX);
    HERO_BODY_X = max(upperTorsoX);
    lArmX[0] = upperTorsoX[1] - 15;
    lArmX[1] = upperTorsoX[1] - 15;
    lArmX[2] = upperTorsoX[1];
    lArmX[3] = upperTorsoX[1];
    rArmX[0] = upperTorsoX[3];
    rArmX[1] = upperTorsoX[3];
    rArmX[2] = upperTorsoX[3] + 15;
    rArmX[3] = upperTorsoX[3] + 15;
}

void drawLeftArm() {
    vector<float> x = lArmX;
    vector<float> y = lArmY;
    glBegin(GL_TRIANGLE_STRIP); {
        if (dark) {
            glColor4f(0.541f, 0.475f, 0.365f, 0.7f);
        } else {
            glColor4f(1.0f, 0.85f, 0.72f, 1.0f);
        }
        for(int i = 0; i < x.size(); i++) {
            glVertex2f(x[i],y[i]);
        }
    }glEnd();
    HERO_LARM_NX = min(lArmX);
    HERO_LARM_NY = min(lArmY);
    HERO_LARM_Y = max(lArmY);
    HERO_LARM_X = max(lArmX);
}

void drawRightArm() {
    vector<float> x = rArmX;
    vector<float> y = rArmY;
    glBegin(GL_TRIANGLE_STRIP); {
        if (dark) {
            glColor4f(0.541f, 0.475f, 0.365f, 1.f);
        } else {
            glColor4f(1.0f, 0.85f, 0.72f, 1.0f);
        }
        for(int i = 0; i < x.size(); i++) {
            glVertex2f(x[i],y[i]);
        }
    }glEnd();
    HERO_RARM_NX = min(rArmX);
    HERO_RARM_NY = min(rArmY);
    HERO_RARM_Y = max(rArmY);
    HERO_RARM_X = max(rArmX);
}

void drawNeck() {
    vector<float> x = neckX;
    vector<float> y = neckY;
    glBegin(GL_TRIANGLE_STRIP);
    {
        if (dark) {
            glColor4f(0.541f, 0.475f, 0.365f, 0.7f);
        } else {
            glColor4f(1.0f, 0.85f, 0.72f, 1.0f);
        }
        for(int i = 0; i < x.size(); i++) {
            glVertex2f(x[i],y[i]);
        }
    }glEnd();
    HERO_NECK_NX = min(neckX);
    HERO_NECK_NY = min(neckY);
    HERO_NECK_Y = max(neckY);
    HERO_NECK_X = max(neckX);
}

void drawEyes() {
    float x1 = 236;
    float x2 = 276;
    float y1 = 356;
    glBegin(GL_TRIANGLE_FAN); {
        if(dark) {
            glColor4f(0.0f,0.0f,0.0f,1.0f);
        } else {
            glColor4f(1.0f,1.0f,1.0f,1.0f);
        }
        glVertex2f(x1,y1);
        for(float i = 0.0f; i <= 2*M_PI; i = i + (M_PI/1000)) {
            glVertex2f(4*cos(i) + x1,4*sin(i) + y1);
        }
    } glEnd();
    glBegin(GL_LINE_STRIP); {
        if(!dark) {
            glColor4f(0.0f,0.0f,0.0f,1.0f);
        } else {
            glColor4f(1.0f,1.0f,1.0f,1.0f);
        }
        for(float i = 0.0f; i <= 2.1*M_PI; i = i + (M_PI/1000)) {
            glVertex2f(4*cos(i) + x1,4*sin(i) + y1);
        }
    } glEnd();
    glBegin(GL_TRIANGLE_FAN); {
        if(dark) {
            glColor4f(0.0f,0.0f,0.0f,1.0f);
        } else {
            glColor4f(1.0f,1.0f,1.0f,1.0f);
        }
        glVertex2f(x1,y1);
        for(float i = 0.0f; i <= 2*M_PI; i = i + (M_PI/1000)) {
            glVertex2f(4*cos(i) + x2,4*sin(i) + y1);
        }
    } glEnd();
    glBegin(GL_LINE_STRIP); {
        if(!dark) {
            glColor4f(0.0f,0.0f,0.0f,1.0f);
        } else {
            glColor4f(1.0f,1.0f,1.0f,1.0f);
        }
        for(float i = 0.0f; i <= 2.1*M_PI; i = i + (M_PI/1000)) {
            glVertex2f(4*cos(i) + x2,4*sin(i) + y1);
        }
    } glEnd();
}

void drawNose() {
    glBegin(GL_LINE_STRIP); {
        if(!dark) {
            glColor4f(0.0f,0.0f,0.0f,1.0f);
        } else {
            glColor4f(1.0f,1.0f,1.0f,1.0f);
        }
        glVertex2f(256.0f, 354.0f);
        glVertex2f(261.0f,344.0f);
        glVertex2f(256.0f,344.0f);
    } glEnd();
}

void drawMouth() {
    glBegin(GL_LINE_STRIP); {
        if(!dark) {
            glColor4f(0.0f,0.0f,0.0f,1.0f);
        } else {
            glColor4f(1.0f,1.0f,1.0f,1.0f);
        }
        for(float i = M_PI; i <= 2.0*M_PI; i = i + (M_PI/1000)) {
            glVertex2f(8*cos(i) + 256,8*sin(i) + 326);
        }
    } glEnd();
}

/*void drawHair() {
    int hairCount = 0;
    glBegin(GL_LINE); {
        if(dark) {
            glColor4f(0.01f, 0.01f, 0.01f, 1.0f);
        } else {
            glColor4f(1.0f, 0.9608f, 0.7176f, 1.0f);
        }
        for(hairCount = 0; hairCount < 10; hairCount++) {
            float rng = (rand() % 5) - 2.5;
            glVertex2f(216 + rng, 376 + rng);
            glVertex2f(296 + rng, 376 + rng);
        }
        for(hairCount = 0; hairCount < 10; hairCount++) {
            float rng = (rand() % 5) - 2.5;
            glVertex2f(296 + rng, 376 + rng);
            glVertex2f(306 + rng, 306 + rng);
        }
    }
}*/

void drawHead() {
    //srand(time(NULL));
    vector<float> x = headX;
    vector<float> y = headY;

    glBegin(GL_TRIANGLE_STRIP); {
        if(dark) {
            glColor4f(0.05f, 0.05f, 0.05f, 1.0f);
        } else {
            glColor4f(0.98f, 0.98f, 0.98f, 1.0f);
        }
        for(int i = 0; i < x.size(); i++) {
            glVertex2f(x[i],y[i]);
        }
    }glEnd();
    glBegin(GL_LINE_STRIP); {
        glColor4f(0.f,0.f,0.f,1.0f);
        glVertex2f(x[0]-1,y[0]);
        glVertex2f(x[1]-1,y[1]);
        glVertex2f(x[3]+1,y[3]);
        glVertex2f(x[2]+1,y[2]);
        glVertex2f(x[0]-1,y[0]);
    }glEnd();
    drawEyes();
    drawNose();
    drawMouth();
    //drawHair();
    HERO_HEAD_NX = min(headX);
    HERO_HEAD_NY = min(headY);
    HERO_HEAD_Y = max(headY);
    HERO_HEAD_X = max(headX);
}

void drawModel() {
    drawNeck();
    drawBody();
    drawUpperTorso();
    drawLeftLeg();
    drawRightLeg();
    drawLeftArm();
    drawRightArm();
    drawHead();
}

void drawBoom() {
    float theta = 0.0;
    srand(time(nullptr));
    glBegin(GL_TRIANGLE_FAN);
    {
        if (tickCounter <= 2) {
            glColor4f(1.0f, 1.0f, 0.0f, 1.0f);
        } else if (tickCounter <= 3) {
            glColor4f(1.0f, 0.647f, 0.0f, 1.0f);
        } else if (tickCounter <= 5) {
            glColor4f(1.0f, 0.0f, 0.0f, 1.0f);
        }
        glVertex2d(mouseX, mouseY);
        while (theta < (2.1 * M_PI)) {
            int radius = (rand() % 50) + 25;
            glVertex2d(radius * cos(theta) + mouseX, radius * sin(theta) + mouseY);
            theta = theta + M_PI / 30;
        }
    }glEnd();
}

GLFWwindow* setupGLFW() {
    // set what function to use when registering errors
    // this is the ONLY GLFW function that can be called BEFORE GLFW is initialized
    // all other GLFW calls must be performed after GLFW has been initialized
    glfwSetErrorCallback( error_callback );

    // initialize GLFW
    if (!glfwInit()) {
        fprintf( stderr, "[ERROR]: Could not initialize GLFW\n" );
        exit(EXIT_FAILURE);
    } else {
        fprintf( stdout, "[INFO]: GLFW initialized\n" );
    }

    glfwWindowHint( GLFW_DOUBLEBUFFER, GLFW_TRUE  );	// use double buffering
    glfwWindowHint( GLFW_CONTEXT_VERSION_MAJOR, 2 );	// request OpenGL v2.X
    glfwWindowHint( GLFW_CONTEXT_VERSION_MINOR, 1 );	// request OpenGL v2.1
    glfwWindowHint( GLFW_RESIZABLE, GLFW_FALSE );		// do not allow our window to be able to be resized

    // create a window for a given size, with a given title
    GLFWwindow *window = glfwCreateWindow( WINDOW_WIDTH, WINDOW_HEIGHT, "Assignment 2", NULL, NULL );
    if( !window ) {
        glfwTerminate();
        exit(EXIT_FAILURE);
    } else {
        fprintf( stdout, "[INFO]: GLFW Window created\n" );
    }

    glfwSetKeyCallback(window, keyboard_callback);
    glfwSetMouseButtonCallback(window, mouse_button_callback);
    glfwSetCursorPosCallback( window, cursor_callback );

    glfwMakeContextCurrent(window);		// make the created window the current window
    glfwSwapInterval(1);				// update our window after at least 1 screen refresh

    return window;						// return the window that was created
}

//
//  void setupOpenGL()
//
//      Used to setup everything OpenGL related.  For now, the only setting
//	we need is what color to make the background of our window when we clear
//	the window.  In the future we will be adding many more settings to this
//	function.
//
void setupOpenGL() {
    glClearColor( 0.0f, 0.0f, 0.0f, 1.0f );	// set the clear color to black
}


//*************************************************************************************
//
// Rendering / Drawing Functions - this is where the magic happens!

//
//	void renderScene()
//
//		This method will contain all of the objects to be drawn.
//
void renderScene() {
    // draw our World Map to the screen.  this MUST be your first drawing call
    drawMap( WINDOW_WIDTH, WINDOW_HEIGHT );	// DO NOT REMOVE THIS LINE
    glm::mat4 transMtx = glm::translate(glm::mat4(1.0f), glm::vec3(translateX, translateY,0.0f));
    glMultMatrixf(&transMtx[0][0]);
    drawModel();
    glm::mat4 scaleMtx;
    if(startBoom) {
        scaleMtx = glm::scale(glm::mat4(1.0f), glm::vec3(tickCounter/2,tickCounter/2,0.0f));
        scaleMtx = glm::translate(scaleMtx, glm::vec3(-(tickCounter/2) + translateX, -(tickCounter/2) + translateY, 0.0));
        glMultMatrixf(&scaleMtx[0][0]);
        drawBoom();
        glMultMatrixf(&(inverse(scaleMtx))[0][0]);
    }
    //////////////////////////////////////////////////////////
    /////			Add Your Drawing Below Here		 	 /////
    //////////////////////////////////////////////////////////
}

//*************************************************************************************
//
// Our main function

//
//	int main( int argc, char *argv[] )
//
//		Really you should know what this is by now.  We will make use of the parameters later
//
int main( int argc, char* argv[] ) {
    GLFWwindow *window = setupGLFW();	// initialize all of the GLFW specific information releated to OpenGL and our window
    // GLFW sets up our OpenGL context so must be done first
    setupOpenGL();						// initialize all of the OpenGL specific information

    initMap();							// initialize our map

    //  This is our draw loop - all rendering is done here.  We use a loop to keep the window open
    //	until the user decides to close the window and quit the program.  Without a loop, the
    //	window will display once and then the program exits.
    while( !glfwWindowShouldClose(window) ) {
        glDrawBuffer( GL_BACK );		// ensure we are drawing to the back buffer
        glClear( GL_COLOR_BUFFER_BIT );	// clear the current color contents in the buffer

        // update the projection matrix based on the window size
        // the GL_PROJECTION matrix governs properties of the view coordinates;
        // i.e. what gets seen - use an Orthographic projection that ranges
        // from [0, windowWidth] in X and [0, windowHeight] in Y. (0,0) is the lower left.
        glm::mat4 projMtx = glm::ortho( 0.0f, (GLfloat)WINDOW_WIDTH, 0.0f, (GLfloat)WINDOW_HEIGHT );
        glMatrixMode( GL_PROJECTION );	// change to the Projection matrix
        glLoadIdentity();				// set the matrix to be the identity
        glMultMatrixf( &projMtx[0][0] );// load our orthographic projection matrix into OpenGL's projection matrix state

        // Get the size of our framebuffer.  Ideally this should be the same dimensions as our window, but
        // when using a Retina display the actual window can be larger than the requested window.  Therefore
        // query what the actual size of the window we are rendering to is.
        GLint framebufferWidth, framebufferHeight;
        glfwGetFramebufferSize( window, &framebufferWidth, &framebufferHeight );

        // update the viewport - tell OpenGL we want to render to the whole window
        glViewport( 0, 0, framebufferWidth, framebufferHeight );

        glMatrixMode( GL_MODELVIEW );	// make the ModelView matrix current to be modified by any transformations
        glLoadIdentity();				// set the matrix to be the identity

        renderScene();					// draw everything to the window
        glfwSwapBuffers(window);		// flush the OpenGL commands and make sure they get rendered!
        glfwPollEvents();				// check for any events and signal to redraw screen
        if(tickCounter < 5  && startBoom) {
            tickCounter= tickCounter + 0.1;
        } else {
            startBoom = false;
        }
    }

    return 0;
}
